package Heartmonitor;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.Parent;
import javafx.scene.text.Text;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javafx.application.Platform;
public class TechnicianView 
{
    private VBox layout = new VBox(10);
    private Main main;
    private Label infoUpdatedLabel;
    public TechnicianView(Main main) 
    {
        this.main = main;
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        HBox patientIDBox = createField("Patient ID", 220);
        HBox totalCACScoreBox = createField("The total Agatston CAC score", 220);
        Text vesselLevelLabel = new Text("Vessel level Agatston CAC score");
        vesselLevelLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: normal;");
        HBox vesselLMBox = createField("LM", 180);
        HBox vesselLADBox = createField("LAD", 180);
        HBox vesselLCXBox = createField("LCX", 180);
        HBox vesselRCABox = createField("RCA", 180);
        HBox vesselPDABox = createField("PDA", 180);
        Button saveButton = new Button("Save");
        saveButton.setStyle("-fx-background-color: #0073e6; -fx-text-fill: black; -fx-padding: 10px 20px;");
        saveButton.setOnAction(e -> 
        {
            saveCTScanData
            (
                ((TextField)patientIDBox.getChildren().get(1)).getText(),
                ((TextField)totalCACScoreBox.getChildren().get(1)).getText(),
                ((TextField)vesselLMBox.getChildren().get(1)).getText(),
                ((TextField)vesselLADBox.getChildren().get(1)).getText(),
                ((TextField)vesselLCXBox.getChildren().get(1)).getText(),
                ((TextField)vesselRCABox.getChildren().get(1)).getText(),
                ((TextField)vesselPDABox.getChildren().get(1)).getText()
            );
            infoUpdatedLabel.setText("Information updated successfully.");
            infoUpdatedLabel.setVisible(true);
            new Thread(() -> 
            {
                try 
                {
                    Thread.sleep(3000);
                    Platform.runLater(() -> infoUpdatedLabel.setVisible(false));
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }).start();
        });
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #0073e6; -fx-text-fill: black; -fx-padding: 10px 20px;");
        backButton.setOnAction(e -> main.switchToMainMenu());
        infoUpdatedLabel = new Label();
        infoUpdatedLabel.setVisible(false);
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        buttonBox.getChildren().addAll(backButton, saveButton);
        layout.getChildren().addAll(
            patientIDBox, totalCACScoreBox, vesselLevelLabel, vesselLMBox, vesselLADBox, vesselLCXBox, vesselRCABox, vesselPDABox, buttonBox, infoUpdatedLabel
        );
    }
    private HBox createField(String labelText, int labelWidth) 
    {
        Label label = new Label(labelText + ":");
        label.setMinWidth(labelWidth);
        TextField textField = new TextField();
        textField.setMinWidth(200);
        HBox hbox = new HBox(10);
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.getChildren().addAll(label, textField);
        return hbox;
    }
    private void saveCTScanData(String patientID, String totalCAC, String lm, String lad, String lcx, String rca, String pda) {
        String filename = patientID + "CTResults.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("Patient ID: " + patientID + "\n");
            writer.write("The total Agatston CAC Score: " + totalCAC + "\n");
            writer.write("LM: " + lm + "\n");
            writer.write("LAD: " + lad + "\n");
            writer.write("LCX: " + lcx + "\n");
            writer.write("RCA: " + rca + "\n");
            writer.write("PDA: " + pda + "\n");
            writer.flush();
        } catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
public Parent asParent() 
{
        return layout;
    }
}