package Heartmonitor;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application 
{
    private Stage primaryStage;
    @Override
    public void start(Stage primaryStage) 
    {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Heart Health Imaging and Recording System");
        setupMenu();
    }
    private void setupMenu() 
    {
        Text title = new Text("Welcome to Heart Health Imaging and Recording System");
        title.setStyle("-fx-font-size: 12px; -fx-font-weight: bold;");
        Button btnPatientIntake = new Button("Patient Intake");
        Button btnCTScanTechView = new Button("CT Scan Tech View");
        Button btnPatientView = new Button("Patient View");
        btnPatientIntake.setStyle("-fx-background-color: #0073e6; -fx-text-fill: white;");
        btnCTScanTechView.setStyle("-fx-background-color: #0073e6; -fx-text-fill: white;");
        btnPatientView.setStyle("-fx-background-color: #0073e6; -fx-text-fill: white;");
        btnPatientIntake.setMinWidth(200);
        btnCTScanTechView.setMinWidth(200);
        btnPatientView.setMinWidth(200);
        btnPatientIntake.setOnAction(e -> switchToRecepView());
        btnCTScanTechView.setOnAction(e -> switchToTechnicianView());
        btnPatientView.setOnAction(e -> switchToPatientView());
        VBox menu = new VBox(10);
        menu.setAlignment(Pos.CENTER);
        menu.getChildren().addAll(title, btnPatientIntake, btnCTScanTechView, btnPatientView);
        Scene scene = new Scene(menu, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void switchToRecepView() 
    {
        ReceptionView view = new ReceptionView(this);
        primaryStage.setScene(new Scene(view.asParent(), 800, 600));
    }
    private void switchToTechnicianView() 
    {
        TechnicianView view = new TechnicianView(this);
        primaryStage.setScene(new Scene(view.asParent(), 800, 600));
    }
    private void switchToPatientView() 
    {
        PatientView view = new PatientView(this);
        primaryStage.setScene(new Scene(view.asParent(), 800, 600));
    }
    public void switchToMainMenu() 
    {
        setupMenu();  
    }
    public static void main(String[] args) 
    {
        launch(args);
    }
}

