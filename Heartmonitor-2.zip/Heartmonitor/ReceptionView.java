package Heartmonitor;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.Parent;
import javafx.scene.text.Text;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
public class ReceptionView 
{
    private VBox layout = new VBox(10);
    private Main main;
    private Label infoSavedLabel;  
    public ReceptionView(Main main) 
    {
        this.main = main;
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        Text title = new Text("Patient Intake Form");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        HBox firstNameBox = createField("First Name");
        HBox lastNameBox = createField("Last Name");
        HBox emailBox = createField("Email");
        HBox phoneNumberBox = createField("Phone Number");
        HBox healthHistoryBox = createField("Health History");
        HBox insuranceIDBox = createField("Insurance ID");
        Button saveButton = new Button("Save");
        saveButton.setStyle("-fx-background-color: #0073e6; -fx-text-fill: black; -fx-padding: 10px 20px;");
        saveButton.setOnAction(e -> {
            int patientID = savePatientInfo(
                ((TextField)firstNameBox.getChildren().get(1)).getText(),
                ((TextField)lastNameBox.getChildren().get(1)).getText(),
                ((TextField)emailBox.getChildren().get(1)).getText(),
                ((TextField)phoneNumberBox.getChildren().get(1)).getText(),
                ((TextField)healthHistoryBox.getChildren().get(1)).getText(),
                ((TextField)insuranceIDBox.getChildren().get(1)).getText()
            );
            infoSavedLabel.setText("Information saved. Patient ID: " + patientID);
            infoSavedLabel.setVisible(true);
            new Thread(() -> 
            {
                try 
                {
                    Thread.sleep(6000);
                    javafx.application.Platform.runLater(() -> infoSavedLabel.setVisible(false));
                } catch (InterruptedException ex) 
                {
                    ex.printStackTrace();
                }
            }).start();
        });
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #0073e6; -fx-text-fill: black; -fx-padding: 10px 20px;");
        backButton.setOnAction(e -> main.switchToMainMenu());
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        buttonBox.getChildren().addAll(backButton, saveButton);
        infoSavedLabel = new Label();
        infoSavedLabel.setVisible(false);
        layout.getChildren().addAll(
            title, firstNameBox, lastNameBox, emailBox, phoneNumberBox, healthHistoryBox, insuranceIDBox, buttonBox, infoSavedLabel
        );
    }
    private HBox createField(String labelText) 
    {
        Label label = new Label(labelText + ":");
        label.setMinWidth(100);
        TextField textField = new TextField();
        textField.setMinWidth(200);
        HBox hbox = new HBox(10);
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.getChildren().addAll(label, textField);
        return hbox;
    }
    private int savePatientInfo(String firstName, String lastName, String email, String phone, String healthHistory, String insuranceID)
    {
        Random rand = new Random();
        int patientID = rand.nextInt(90000) + 10000;
        String filename = patientID + "_PatientInfo.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("First Name: " + firstName + "\n");
            writer.write("Last Name: " + lastName + "\n");
            writer.write("Email: " + email + "\n");
            writer.write("Phone Number: " + phone + "\n");
            writer.write("Health History: " + healthHistory + "\n");
            writer.write("Insurance ID: " + insuranceID + "\n");
            writer.flush();
        } catch (IOException e) 
        {
            e.printStackTrace();
        }
        return patientID;
    }
    public Parent asParent() 
{
        return layout;
    }
}
