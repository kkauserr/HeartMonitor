package Heartmonitor;

import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.Parent;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class PatientView {
    private VBox layout = new VBox(10);
    private Main main;
    public PatientView(Main main) 
    {
        this.main = main;
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        TextField patientIDField = new TextField();
        patientIDField.setPromptText("Enter Patient ID");
        Button loadResultsButton = new Button("Load Results");
        loadResultsButton.setStyle("-fx-background-color: #0073e6; -fx-text-fill: white; -fx-padding: 10px 20px;");
        HBox patientIDBox = createDataField("Patient ID:");
        HBox totalCACScoreBox = createDataField("The total Agatston CAC Score:");
        HBox lmBox = createDataField("LM:");
        HBox ladBox = createDataField("LAD:");
        HBox lcxBox = createDataField("LCX:");
        HBox rcaBox = createDataField("RCA:");
        HBox pdaBox = createDataField("PDA:");
        loadResultsButton.setOnAction(e -> 
        {
            loadPatientData(patientIDField.getText(), patientIDBox, totalCACScoreBox, lmBox, ladBox, lcxBox, rcaBox, pdaBox);
        });
        layout.getChildren().addAll(new Label("Patient ID"), patientIDField, loadResultsButton);
        layout.getChildren().addAll(patientIDBox, totalCACScoreBox, lmBox, ladBox, lcxBox, rcaBox, pdaBox);
    }
    private HBox createDataField(String labelText) 
    {
        Label label = new Label(labelText);
        TextField textField = new TextField();
        textField.setEditable(false);
        HBox hbox = new HBox(10);
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.getChildren().addAll(label, textField);
        return hbox;
    }
    private void loadPatientData(String patientID, HBox... dataBoxes) 
    {
        String filename = patientID + "CTResults.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) 
        {
            String line;
            while ((line = reader.readLine()) != null) 
            {
                System.out.println("Read line: " + line); 
                String[] parts = line.split(":");
                if (parts.length > 1) {
                    String key = parts[0].trim();
                    String value = parts[1].trim();
                    System.out.println("Key: '" + key + "' Value: '" + value + "'"); 
                    updateField(key, value, dataBoxes);
                }
            }
        } catch (IOException e) 
        {
            ((TextField) dataBoxes[0].getChildren().get(1)).setText("No data available or wrong patient ID.");
            e.printStackTrace();
        }
    }private void updateField(String key, String value, HBox[] dataBoxes) 
    {
        for (HBox hbox : dataBoxes) 
        {
            Label label = (Label) hbox.getChildren().get(0);
            if (label.getText().startsWith(key + ":")) { 
                ((TextField) hbox.getChildren().get(1)).setText(value);
                break;
            }
        }
    }
    public Parent asParent() 
    {
        return layout;
    }
}
